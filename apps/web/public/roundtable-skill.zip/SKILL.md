---
name: moltron-roundtable
description: Self-bootstrapping R&D Council. Drop it in, say "run the roundtable" — the skill sets itself up, spawns 4 seat agents on the fly, runs a debate, synthesizes a strategic memo, and saves it. Zero pre-configuration required.
triggers:
  - "run the R&D council"
  - "run the roundtable"
  - "council session"
  - "roundtable"
  - "run the council"
---

# moltron-roundtable Skill

**Zero-setup R&D Council.** 4 AI seat agents debate one bold idea. You synthesize. Memo saved locally.

No permanent agents required — seats are spawned on the fly for each session.

---

## How to Execute (follow every step in order)

### Step 1 — Check for config

Look for `skills/moltron-roundtable/config.json`.

**If it exists:** load it and jump to Step 3.

**If it does NOT exist:** run the bootstrap flow (Step 2).

---

### Step 2 — Bootstrap (first run only)

The user has no config. Gather what you need — either from memory or by asking.

#### 2a — Load from memory first

Use `memory_search` to look for:
- Business context: `"business mission products target customer"`
- User name / founder name
- Any revenue goals

If you find enough context (business description + goal), pre-fill what you can.

#### 2b — Ask only what you can't find

Ask the user ONE message with all missing fields. Keep it tight:

```
To run your first R&D Council I need a few details:

1. What does your business do? (1-2 sentences — who you serve, what you sell)
2. What's your current revenue goal or main constraint?
3. What Slack channel should I post memos to? (e.g. #general) — or type "skip" to skip Slack

That's it. I'll handle the rest.
```

Wait for their reply.

#### 2c — Write config.json

From memory + user reply, write `skills/moltron-roundtable/config.json`:

```json
{
  "business_context": "<their business description + goal in 100-200 words>",
  "slack_channel_id": "<channel id if provided, null if skipped>",
  "slack_channel_name": "<channel name if provided, null if skipped>",
  "obsidian_vault_path": null,
  "seats": [
    {
      "index": 0,
      "name": "Provocateur",
      "emoji": "🔴",
      "persona": "Bold, lateral thinker. Generates surprising non-obvious ideas. Pushes on what others won't say. Biased toward action and asymmetric bets."
    },
    {
      "index": 1,
      "name": "Operator",
      "emoji": "🔵",
      "persona": "Hard-nosed execution focus. Evaluates shippability, first steps, hidden complexity. Asks: what breaks first and how long does this actually take?"
    },
    {
      "index": 2,
      "name": "Skeptic",
      "emoji": "🟡",
      "persona": "Sharp analytical critic. Finds real weaknesses, false assumptions, failure modes. Not contrarian for sport — genuinely stress-tests ideas."
    },
    {
      "index": 3,
      "name": "Customer",
      "emoji": "🟢",
      "persona": "Voice of the ideal customer. Reacts like a buyer who has the problem but is skeptical of solutions. Cuts through features to ask: does this actually solve my pain?"
    }
  ]
}
```

Tell the user: "Config saved. Running your first council session now..."

Then continue to Step 3.

---

### Step 3 — Load state

Read `skills/moltron-roundtable/council-state.json`.

If it doesn't exist, initialise:
```json
{ "lastProposerIndex": -1, "sessionCount": 0, "lastRunAt": null }
```

Determine:
```
N = sessionCount + 1
proposerIndex = (lastProposerIndex + 1) % 4
proposer = config.seats[proposerIndex]
```

---

### Step 4 — Spawn proposer agent and get idea

Use `sessions_spawn` to create a one-shot agent for the proposer seat:

```
runtime: "subagent"
mode: "run"
task: |
  [R&D COUNCIL — Session #{N} | {DATE} {TIME}]

  You are the {PROPOSER_EMOJI} {PROPOSER_NAME} seat on an R&D council.
  Your role: {PROPOSER_PERSONA}

  Business context:
  {config.business_context}

  {LAST_3_MEMO_SUMMARIES_IF_ANY}

  YOUR TASK: Generate ONE specific, bold business idea right now.
  - Name it clearly
  - One sharp paragraph of rationale (4-6 sentences)
  - Concrete and specific — no platitudes, no hedging
  - Do not ask questions. Just propose.
```

Wait for the spawned agent's result. Extract the proposal text.

---

### Step 5 — Spawn 3 debate agents (in parallel if possible)

For each of the 3 remaining seats, use `sessions_spawn`:

```
runtime: "subagent"
mode: "run"
task: |
  [R&D COUNCIL — Session #{N} | Responding to {PROPOSER_NAME}]

  You are the {SEAT_EMOJI} {SEAT_NAME} seat on an R&D council.
  Your role: {SEAT_PERSONA}

  Business context:
  {config.business_context}

  ---

  {PROPOSER_EMOJI} {PROPOSER_NAME} proposes:

  {PROPOSAL}

  ---

  Respond from your role. 3-5 sentences. Direct. No pleasantries. No summary of the proposal — just your take.
```

Collect all 3 responses.

**If a spawn fails:** note the seat as `[unavailable]` and continue. Don't abort.

---

### Step 6 — Synthesize memo (inline — you write this, no spawning)

Write a strategic memo synthesizing the full debate:

```markdown
# 🧠 R&D Council — Session #{N}
**{DATE} {TIME} | {SESSION_TYPE}**
**Proposer: {PROPOSER_EMOJI} {PROPOSER_NAME}**

---

## 💡 The Idea
{ONE_SHARP_SENTENCE_SUMMARY}

{PROPOSER_EMOJI} **{PROPOSER_NAME}:** {FULL_PROPOSAL}

---

## The Debate

**{SEAT_1_EMOJI} {SEAT_1_NAME}:** {RESPONSE}

**{SEAT_2_EMOJI} {SEAT_2_NAME}:** {RESPONSE}

**{SEAT_3_EMOJI} {SEAT_3_NAME}:** {RESPONSE}

---

## 📋 Strategic Memo

{2-3_PARAGRAPHS — synthesize the sharpest points from all 4 agents. What's the real insight? What's the biggest risk? What does this unlock if it works?}

**Top 3 Actions:**
1. {SPECIFIC_ACTION — owner + timeframe}
2. {SPECIFIC_ACTION — owner + timeframe}
3. {SPECIFIC_ACTION — owner + timeframe}
```

---

### Step 7 — Save memo

Write memo to:
1. `skills/moltron-roundtable/memos/{DATE}-session-{N}.md` (always)
2. `{config.obsidian_vault_path}/20 Knowledge/R&D Council/{DATE}-session-{N}.md` (only if obsidian_vault_path is set)

Create folders if they don't exist.

---

### Step 8 — Update state

```json
{
  "lastProposerIndex": {proposerIndex},
  "sessionCount": {N},
  "lastRunAt": "{ISO_TIMESTAMP}"
}
```

---

### Step 9 — Post to Slack (if configured)

If `config.slack_channel_id` is set, post the full memo using the `message` tool.

If not configured, show the memo inline in the current conversation.

---

## Seat Roles

| Seat | Default Role | What they do |
|------|-------------|-------------|
| 0 | Provocateur 🔴 | Bold lateral thinking — surprising non-obvious ideas |
| 1 | Operator 🔵 | Execution realist — shippability, first steps, hidden complexity |
| 2 | Skeptic 🟡 | Analytical critic — weaknesses, false assumptions, failure modes |
| 3 | Customer 🟢 | Buyer voice — reacts to the idea as your ideal customer would |

The coordinator (main session) is the **Strategist** — synthesizes the debate, writes the memo.

Seats rotate as proposer each session: 0 → 1 → 2 → 3 → 0 → ...

---

## Error Handling

- If a spawned agent fails, mark the seat `[unavailable]` in the memo and continue.
- If 2+ agents fail, note it and synthesize from what you have — a partial session is better than no session.
- Never `sessions_spawn` targeting yourself — self-call loop. Write the synthesis inline.

---

## Optional: Run on a schedule

Once the skill is bootstrapped, add cron jobs via OpenClaw:

```
Morning:   0 9  * * *  (your timezone)
payload → "Run the roundtable (morning session). Follow the moltron-roundtable skill."

Afternoon: 0 17 * * *  (your timezone)
payload → "Run the roundtable (afternoon session). Follow the moltron-roundtable skill."
```

---

## Files

| File | Purpose |
|------|---------|
| `SKILL.md` | This file — skill instructions |
| `config.example.json` | Template showing all config fields |
| `config.json` | Your config — auto-created on first run (gitignored) |
| `council-state.json` | Auto-managed rotation state |
| `memos/` | All session memos |
