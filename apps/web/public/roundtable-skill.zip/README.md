# moltron-roundtable

**A self-bootstrapping R&D Council for OpenClaw.**

Drop it in your `skills/` folder. Say `"run the roundtable"`. Done.

No pre-configured agents required. The skill spawns 4 debate seats on the fly, asks you 2-3 questions on first run, then runs a full strategic council session — proposal, debate, synthesis, memo.

---

## How it works

1. **First run:** skill checks for config, finds none, asks you 2-3 questions about your business
2. **Auto-setup:** writes `config.json` from your answers + anything already in your memory
3. **Council runs:** spawns 4 one-shot agents (Provocateur, Operator, Skeptic, Customer)
4. **Debate:** proposer generates a bold idea; other 3 respond from their roles
5. **Synthesis:** coordinator writes a strategic memo with top 3 actions
6. **Delivery:** memo saved to `memos/` + Obsidian vault (if configured) + posted to Slack (if configured)

Every subsequent run skips straight to the debate.

---

## Install

```bash
# Copy the skill folder into your OpenClaw workspace
cp -r moltron-roundtable /path/to/your/openclaw/workspace/skills/

# That's it. Now say "run the roundtable" to your agent.
```

---

## First run experience

```
You: run the roundtable

Agent: To run your first R&D Council I need a few details:

  1. What does your business do? (1-2 sentences)
  2. What's your current revenue goal or main constraint?
  3. What Slack channel should I post memos to? (or "skip")

You: [answers]

Agent: Config saved. Running your first council session now...

  🧠 R&D Council — Session #1
  ...full memo...
```

---

## What gets created

| File | When |
|------|------|
| `config.json` | First run (auto-generated from your answers) |
| `council-state.json` | Auto-managed — tracks rotation and session count |
| `memos/YYYY-MM-DD-session-N.md` | Every session |

---

## Seat roles

| Seat | Role | What they do |
|------|------|-------------|
| 🔴 Provocateur | Idea generator | Bold, lateral, non-obvious proposals |
| 🔵 Operator | Execution realist | Shippability, first steps, hidden complexity |
| 🟡 Skeptic | Analyst | Weaknesses, false assumptions, failure modes |
| 🟢 Customer | Buyer voice | Reacts as your ideal customer |

Seats rotate as proposer each session. The coordinator (your main agent) synthesizes.

---

## Optional: schedule it

Once bootstrapped, set up cron jobs:

```
Morning:   "Run the roundtable (morning session). Follow the moltron-roundtable skill."
Afternoon: "Run the roundtable (afternoon session). Follow the moltron-roundtable skill."
```

---

## Customising

Edit `config.json` to:
- Change seat personas to match your team's roles/voices
- Add your Obsidian vault path for persistent memo storage
- Adjust Slack channel

See `config.example.json` for all available fields.
